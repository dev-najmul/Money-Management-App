import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Transaction } from "@/lib/finance-types";
import { toast } from "sonner";

export const useTransactions = () => {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchTransactions = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from("transactions")
      .select("*")
      .eq("user_id", user.id)
      .order("date", { ascending: false });

    if (error) {
      toast.error("লেনদেন লোড করতে সমস্যা হয়েছে");
      return;
    }

    setTransactions(
      (data || []).map((t) => ({
        id: t.id,
        amount: Number(t.amount),
        type: t.type as "income" | "expense",
        category: t.category as Transaction["category"],
        note: t.note,
        source: t.source as "cash" | "bank",
        date: t.date,
      }))
    );
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchTransactions();
  }, [fetchTransactions]);

  const addTransaction = async (txn: Omit<Transaction, "id">) => {
    if (!user) return;
    const { error } = await supabase.from("transactions").insert({
      user_id: user.id,
      amount: txn.amount,
      type: txn.type,
      category: txn.category,
      note: txn.note,
      source: txn.source,
      date: txn.date,
    });
    if (error) {
      toast.error("লেনদেন সেভ করতে সমস্যা হয়েছে");
      return;
    }
    await fetchTransactions();
  };

  const updateTransaction = async (txn: Transaction) => {
    const { error } = await supabase
      .from("transactions")
      .update({
        amount: txn.amount,
        type: txn.type,
        category: txn.category,
        note: txn.note,
        source: txn.source,
      })
      .eq("id", txn.id);
    if (error) {
      toast.error("আপডেট করতে সমস্যা হয়েছে");
      return;
    }
    await fetchTransactions();
  };

  const deleteTransaction = async (id: string) => {
    const { error } = await supabase.from("transactions").delete().eq("id", id);
    if (error) {
      toast.error("ডিলিট করতে সমস্যা হয়েছে");
      return;
    }
    await fetchTransactions();
  };

  return { transactions, loading, addTransaction, updateTransaction, deleteTransaction };
};
