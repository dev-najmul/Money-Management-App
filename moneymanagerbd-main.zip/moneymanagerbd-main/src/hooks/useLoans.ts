import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Loan, LoanPayment } from "@/lib/finance-types";
import { toast } from "sonner";

export const useLoans = () => {
  const { user } = useAuth();
  const [loans, setLoans] = useState<Loan[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLoans = useCallback(async () => {
    if (!user) return;
    const { data: loansData, error: loansError } = await supabase
      .from("loans")
      .select("*")
      .eq("user_id", user.id);

    if (loansError) {
      toast.error("লোন লোড করতে সমস্যা হয়েছে");
      return;
    }

    const { data: paymentsData } = await supabase
      .from("loan_payments")
      .select("*")
      .eq("user_id", user.id);

    const paymentsByLoan = (paymentsData || []).reduce((acc, p) => {
      if (!acc[p.loan_id]) acc[p.loan_id] = [];
      acc[p.loan_id].push({
        id: p.id,
        amount: Number(p.amount),
        date: p.date,
      });
      return acc;
    }, {} as Record<string, LoanPayment[]>);

    setLoans(
      (loansData || []).map((l) => ({
        id: l.id,
        name: l.name,
        type: l.type as "given" | "taken",
        personName: l.person_name,
        totalAmount: Number(l.total_amount),
        remainingAmount: Number(l.remaining_amount),
        emiAmount: l.emi_amount ? Number(l.emi_amount) : undefined,
        emiDay: l.emi_day ?? undefined,
        createdAt: l.created_at,
        payments: paymentsByLoan[l.id] || [],
      }))
    );
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchLoans();
  }, [fetchLoans]);

  const addLoan = async (loan: Omit<Loan, "id" | "createdAt" | "payments">) => {
    if (!user) return;
    const { error } = await supabase.from("loans").insert({
      user_id: user.id,
      name: loan.name,
      type: loan.type,
      person_name: loan.personName,
      total_amount: loan.totalAmount,
      remaining_amount: loan.remainingAmount,
      emi_amount: loan.emiAmount || null,
      emi_day: loan.emiDay || null,
    });
    if (error) {
      toast.error("লোন সেভ করতে সমস্যা হয়েছে");
      return;
    }
    await fetchLoans();
  };

  const addPayment = async (loanId: string, amount: number) => {
    if (!user) return;
    const { error: payError } = await supabase.from("loan_payments").insert({
      loan_id: loanId,
      user_id: user.id,
      amount,
    });
    if (payError) {
      toast.error("পেমেন্ট সেভ করতে সমস্যা হয়েছে");
      return;
    }

    const loan = loans.find((l) => l.id === loanId);
    if (loan) {
      await supabase
        .from("loans")
        .update({ remaining_amount: Math.max(0, loan.remainingAmount - amount) })
        .eq("id", loanId);
    }
    await fetchLoans();
  };

  const deleteLoan = async (id: string) => {
    const { error } = await supabase.from("loans").delete().eq("id", id);
    if (error) {
      toast.error("ডিলিট করতে সমস্যা হয়েছে");
      return;
    }
    await fetchLoans();
  };

  return { loans, loading, addLoan, addPayment, deleteLoan };
};
