import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { SavingsGoal, SavingsDeposit } from "@/lib/finance-types";
import { toast } from "sonner";

export const useSavings = () => {
  const { user } = useAuth();
  const [goals, setGoals] = useState<SavingsGoal[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchGoals = useCallback(async () => {
    if (!user) return;
    const { data: goalsData, error: goalsError } = await supabase
      .from("savings_goals")
      .select("*")
      .eq("user_id", user.id);

    if (goalsError) {
      toast.error("সঞ্চয় লোড করতে সমস্যা হয়েছে");
      return;
    }

    const { data: depositsData } = await supabase
      .from("savings_deposits")
      .select("*")
      .eq("user_id", user.id);

    const depositsByGoal = (depositsData || []).reduce((acc, d) => {
      if (!acc[d.goal_id]) acc[d.goal_id] = [];
      acc[d.goal_id].push({
        id: d.id,
        amount: Number(d.amount),
        date: d.date,
      });
      return acc;
    }, {} as Record<string, SavingsDeposit[]>);

    setGoals(
      (goalsData || []).map((g) => ({
        id: g.id,
        name: g.name,
        targetAmount: Number(g.target_amount),
        savedAmount: Number(g.saved_amount),
        icon: g.icon,
        createdAt: g.created_at,
        deposits: depositsByGoal[g.id] || [],
      }))
    );
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchGoals();
  }, [fetchGoals]);

  const addGoal = async (goal: { name: string; targetAmount: number; icon: string }) => {
    if (!user) return;
    const { error } = await supabase.from("savings_goals").insert({
      user_id: user.id,
      name: goal.name,
      target_amount: goal.targetAmount,
      icon: goal.icon,
    });
    if (error) {
      toast.error("সঞ্চয় লক্ষ্য সেভ করতে সমস্যা হয়েছে");
      return;
    }
    await fetchGoals();
  };

  const addDeposit = async (goalId: string, amount: number) => {
    if (!user) return;
    const { error: depositError } = await supabase.from("savings_deposits").insert({
      goal_id: goalId,
      user_id: user.id,
      amount,
    });
    if (depositError) {
      toast.error("জমা করতে সমস্যা হয়েছে");
      return;
    }

    // Update saved_amount
    const goal = goals.find((g) => g.id === goalId);
    if (goal) {
      await supabase
        .from("savings_goals")
        .update({ saved_amount: goal.savedAmount + amount })
        .eq("id", goalId);
    }
    await fetchGoals();
  };

  const deleteGoal = async (id: string) => {
    const { error } = await supabase.from("savings_goals").delete().eq("id", id);
    if (error) {
      toast.error("ডিলিট করতে সমস্যা হয়েছে");
      return;
    }
    await fetchGoals();
  };

  return { goals, loading, addGoal, addDeposit, deleteGoal };
};
