import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Budget, TransactionCategory } from "@/lib/finance-types";
import { toast } from "sonner";

export const useBudgets = () => {
  const { user } = useAuth();
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchBudgets = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from("budgets")
      .select("*")
      .eq("user_id", user.id);

    if (error) {
      toast.error("বাজেট লোড করতে সমস্যা হয়েছে");
      return;
    }

    setBudgets(
      (data || []).map((b) => ({
        id: b.id,
        category: b.category as TransactionCategory,
        limit: Number(b.limit),
        month: b.month,
      }))
    );
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchBudgets();
  }, [fetchBudgets]);

  const addBudget = async (budget: Omit<Budget, "id">) => {
    if (!user) return;
    const { error } = await supabase.from("budgets").insert({
      user_id: user.id,
      category: budget.category,
      limit: budget.limit,
      month: budget.month,
    });
    if (error) {
      toast.error("বাজেট সেভ করতে সমস্যা হয়েছে");
      return;
    }
    await fetchBudgets();
  };

  const updateBudget = async (id: string, updates: Partial<Budget>) => {
    const { error } = await supabase
      .from("budgets")
      .update({ category: updates.category, limit: updates.limit })
      .eq("id", id);
    if (error) {
      toast.error("আপডেট করতে সমস্যা হয়েছে");
      return;
    }
    await fetchBudgets();
  };

  const deleteBudget = async (id: string) => {
    const { error } = await supabase.from("budgets").delete().eq("id", id);
    if (error) {
      toast.error("ডিলিট করতে সমস্যা হয়েছে");
      return;
    }
    await fetchBudgets();
  };

  return { budgets, loading, addBudget, updateBudget, deleteBudget };
};
