import { useState, useEffect } from "react";
import { Transaction, TransactionCategory, CATEGORIES } from "@/lib/finance-types";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface AddTransactionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAdd: (transaction: Omit<Transaction, "id">) => void;
  editTransaction?: Transaction | null;
  onUpdate?: (transaction: Transaction) => void;
}

const AddTransactionDialog = ({ open, onOpenChange, onAdd, editTransaction, onUpdate }: AddTransactionDialogProps) => {
  const [amount, setAmount] = useState("");
  const [type, setType] = useState<"income" | "expense">("expense");
  const [category, setCategory] = useState<TransactionCategory>("food");
  const [note, setNote] = useState("");
  const [source, setSource] = useState<"cash" | "bank">("cash");

  const isEditing = !!editTransaction;

  useEffect(() => {
    if (editTransaction) {
      setAmount(String(editTransaction.amount));
      setType(editTransaction.type);
      setCategory(editTransaction.category);
      setNote(editTransaction.note);
      setSource(editTransaction.source);
    } else {
      setAmount("");
      setType("expense");
      setCategory("food");
      setNote("");
      setSource("cash");
    }
  }, [editTransaction, open]);

  const handleSubmit = () => {
    if (!amount || parseFloat(amount) <= 0) return;

    if (isEditing && onUpdate && editTransaction) {
      onUpdate({
        ...editTransaction,
        amount: parseFloat(amount),
        type,
        category,
        note: note || CATEGORIES[category].label,
        source,
      });
    } else {
      onAdd({
        amount: parseFloat(amount),
        type,
        category,
        note: note || CATEGORIES[category].label,
        source,
        date: new Date().toISOString(),
      });
    }
    setAmount("");
    setNote("");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md mx-4 rounded-2xl border-border bg-card">
        <DialogHeader>
          <DialogTitle className="text-foreground text-lg font-semibold">
            {isEditing ? "লেনদেন সম্পাদনা" : "নতুন লেনদেন"}
          </DialogTitle>
        </DialogHeader>

        {/* Type Toggle */}
        <div className="flex gap-2 p-1 bg-secondary rounded-xl">
          <button
            onClick={() => setType("expense")}
            className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
              type === "expense"
                ? "bg-expense text-expense-foreground shadow-sm"
                : "text-muted-foreground"
            }`}
          >
            খরচ
          </button>
          <button
            onClick={() => setType("income")}
            className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
              type === "income"
                ? "bg-income text-income-foreground shadow-sm"
                : "text-muted-foreground"
            }`}
          >
            আয়
          </button>
        </div>

        {/* Amount Input */}
        <div className="text-center py-4">
          <div className="flex items-center justify-center gap-1">
            <span className="text-3xl font-bold text-foreground">৳</span>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0"
              autoFocus
              className="text-4xl font-bold text-center bg-transparent outline-none w-48 text-foreground placeholder:text-muted-foreground font-mono"
            />
          </div>
        </div>

        {/* Source Toggle */}
        <div className="flex gap-2 p-1 bg-secondary rounded-xl">
          <button
            onClick={() => setSource("cash")}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
              source === "cash"
                ? "bg-card text-foreground shadow-sm"
                : "text-muted-foreground"
            }`}
          >
            💵 নগদ
          </button>
          <button
            onClick={() => setSource("bank")}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
              source === "bank"
                ? "bg-card text-foreground shadow-sm"
                : "text-muted-foreground"
            }`}
          >
            🏦 ব্যাংক
          </button>
        </div>

        {/* Categories */}
        <div className="grid grid-cols-4 gap-2">
          {(Object.keys(CATEGORIES) as TransactionCategory[]).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`flex flex-col items-center gap-1 p-2.5 rounded-xl text-xs transition-all ${
                category === cat
                  ? "bg-accent text-accent-foreground ring-1 ring-primary/30"
                  : "bg-secondary text-muted-foreground hover:bg-accent/50"
              }`}
            >
              <span className="text-lg">{CATEGORIES[cat].icon}</span>
              <span className="font-medium">{CATEGORIES[cat].label}</span>
            </button>
          ))}
        </div>

        {/* Note */}
        <input
          type="text"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="নোট (ঐচ্ছিক)"
          className="w-full px-4 py-3 bg-secondary rounded-xl text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-ring"
        />

        {/* Submit */}
        <button
          onClick={handleSubmit}
          className={`w-full py-3.5 rounded-xl text-sm font-semibold transition-all ${
            type === "expense"
              ? "bg-expense text-expense-foreground hover:opacity-90"
              : "bg-income text-income-foreground hover:opacity-90"
          }`}
        >
          {isEditing ? "আপডেট করুন" : "সেভ করুন"}
        </button>
      </DialogContent>
    </Dialog>
  );
};

export default AddTransactionDialog;
