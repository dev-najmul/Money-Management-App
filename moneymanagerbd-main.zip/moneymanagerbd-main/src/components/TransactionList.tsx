import { useState } from "react";
import { Pencil, Trash2 } from "lucide-react";
import { Transaction, CATEGORIES } from "@/lib/finance-types";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface TransactionListProps {
  transactions: Transaction[];
  onDelete?: (id: string) => void;
  onEdit?: (transaction: Transaction) => void;
}

const TransactionList = ({ transactions, onDelete, onEdit }: TransactionListProps) => {
  const [deleteId, setDeleteId] = useState<string | null>(null);

  if (transactions.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <span className="text-5xl block mb-3">💰</span>
        <p className="text-sm">এখনো কোনো লেনদেন নেই</p>
        <p className="text-xs mt-1">নিচের '+' বাটন দিয়ে যুক্ত করুন</p>
      </div>
    );
  }

  const grouped = transactions.reduce((acc, t) => {
    const date = new Date(t.date).toLocaleDateString("bn-BD", {
      day: "numeric",
      month: "long",
    });
    if (!acc[date]) acc[date] = [];
    acc[date].push(t);
    return acc;
  }, {} as Record<string, Transaction[]>);

  return (
    <>
      <div className="space-y-4">
        {Object.entries(grouped).map(([date, txns]) => (
          <div key={date}>
            <p className="text-xs font-medium text-muted-foreground mb-2 px-1">{date}</p>
            <div className="space-y-1.5">
              {txns.map((t) => (
                <div
                  key={t.id}
                  className="flex items-center gap-3 p-3 rounded-xl bg-card hover:bg-accent/30 transition-colors group"
                >
                  <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center text-lg">
                    {CATEGORIES[t.category]?.icon || "📌"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{t.note}</p>
                    <p className="text-xs text-muted-foreground">
                      {t.source === "cash" ? "নগদ" : "ব্যাংক"}
                    </p>
                  </div>
                  <span
                    className={`text-sm font-semibold font-mono ${
                      t.type === "income" ? "text-income" : "text-expense"
                    }`}
                  >
                    {t.type === "income" ? "+" : "-"}৳{t.amount.toLocaleString("bn-BD")}
                  </span>
                  {/* Action buttons */}
                  <div className="flex gap-1 md:opacity-0 md:group-hover:opacity-100 transition-opacity">
                    {onEdit && (
                      <button
                        onClick={() => onEdit(t)}
                        className="p-1.5 rounded-lg hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"
                      >
                        <Pencil size={14} />
                      </button>
                    )}
                    {onDelete && (
                      <button
                        onClick={() => setDeleteId(t.id)}
                        className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="rounded-2xl border-border bg-card mx-4">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-foreground">লেনদেন মুছবেন?</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">
              এই লেনদেনটি স্থায়ীভাবে মুছে যাবে। এটি পূর্বাবস্থায় ফেরানো যাবে না।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-xl">বাতিল</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90 rounded-xl"
              onClick={() => {
                if (deleteId && onDelete) onDelete(deleteId);
                setDeleteId(null);
              }}
            >
              মুছুন
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default TransactionList;
