import { useState } from "react";
import { Plus, Trash2, Banknote, ArrowDownCircle, ArrowUpCircle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { useLoans } from "@/hooks/useLoans";
import BottomNav from "@/components/BottomNav";
import ThemeToggle from "@/components/ThemeToggle";

const LoanPage = () => {
  const { loans, addLoan, addPayment, deleteLoan } = useLoans();
  const [addOpen, setAddOpen] = useState(false);
  const [payLoanId, setPayLoanId] = useState<string | null>(null);

  const [loanName, setLoanName] = useState("");
  const [loanType, setLoanType] = useState<"given" | "taken">("taken");
  const [personName, setPersonName] = useState("");
  const [totalAmount, setTotalAmount] = useState("");
  const [emiAmount, setEmiAmount] = useState("");
  const [emiDay, setEmiDay] = useState("");
  const [payAmount, setPayAmount] = useState("");

  const resetForm = () => {
    setLoanName(""); setLoanType("taken"); setPersonName("");
    setTotalAmount(""); setEmiAmount(""); setEmiDay("");
  };

  const handleAddLoan = async () => {
    if (!loanName || !personName || !totalAmount || parseFloat(totalAmount) <= 0) return;
    await addLoan({
      name: loanName,
      type: loanType,
      personName,
      totalAmount: parseFloat(totalAmount),
      remainingAmount: parseFloat(totalAmount),
      emiAmount: emiAmount ? parseFloat(emiAmount) : undefined,
      emiDay: emiDay ? parseInt(emiDay) : undefined,
    });
    setAddOpen(false);
    resetForm();
  };

  const handlePayment = async () => {
    if (!payLoanId || !payAmount || parseFloat(payAmount) <= 0) return;
    await addPayment(payLoanId, parseFloat(payAmount));
    setPayLoanId(null);
    setPayAmount("");
  };

  const totalGiven = loans.filter((l) => l.type === "given").reduce((s, l) => s + l.remainingAmount, 0);
  const totalTaken = loans.filter((l) => l.type === "taken").reduce((s, l) => s + l.remainingAmount, 0);

  const getNextEmiDate = (loan: { emiDay?: number }) => {
    if (!loan.emiDay) return null;
    const now = new Date();
    const thisMonth = new Date(now.getFullYear(), now.getMonth(), loan.emiDay);
    if (thisMonth > now) return thisMonth;
    return new Date(now.getFullYear(), now.getMonth() + 1, loan.emiDay);
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="px-5 pt-6 pb-4 flex items-center justify-between">
        <h1 className="text-xl font-bold text-foreground">লোন ও EMI</h1>
        <ThemeToggle />
      </div>
      <div className="px-5">
        <div className="flex items-center justify-end mb-4">
          <button onClick={() => { resetForm(); setAddOpen(true); }} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium">
            <Plus size={16} /> যুক্ত করুন
          </button>
        </div>

        {loans.length > 0 && (
          <div className="flex gap-3 mb-4">
            <div className="flex-1 p-3 rounded-xl bg-expense/10 border border-expense/20">
              <p className="text-xs text-muted-foreground">ধার নিয়েছি</p>
              <p className="text-base font-bold font-mono text-expense">৳{totalTaken.toLocaleString("bn-BD")}</p>
            </div>
            <div className="flex-1 p-3 rounded-xl bg-income/10 border border-income/20">
              <p className="text-xs text-muted-foreground">ধার দিয়েছি</p>
              <p className="text-base font-bold font-mono text-income">৳{totalGiven.toLocaleString("bn-BD")}</p>
            </div>
          </div>
        )}

        {loans.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <span className="text-5xl block mb-3">🤝</span>
            <p className="text-sm">কোনো লোন এন্ট্রি নেই</p>
            <p className="text-xs mt-1">ধার নেওয়া বা দেওয়ার হিসাব রাখুন</p>
          </div>
        ) : (
          <div className="space-y-3">
            {loans.map((loan) => {
              const paid = loan.totalAmount - loan.remainingAmount;
              const percentage = (paid / loan.totalAmount) * 100;
              const isComplete = loan.remainingAmount <= 0;
              const nextEmi = getNextEmiDate(loan);
              return (
                <div key={loan.id} className={`p-4 rounded-2xl bg-card border transition-all ${isComplete ? "border-income/50 bg-income/5" : "border-border"}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2.5">
                      {loan.type === "taken" ? <ArrowDownCircle size={20} className="text-expense" /> : <ArrowUpCircle size={20} className="text-income" />}
                      <div>
                        <p className="text-sm font-semibold text-foreground">{loan.name}</p>
                        <p className="text-xs text-muted-foreground">{loan.type === "taken" ? "ধার নিয়েছি" : "ধার দিয়েছি"} — {loan.personName}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      {!isComplete && <button onClick={() => setPayLoanId(loan.id)} className="p-1.5 rounded-lg hover:bg-secondary text-primary"><Banknote size={16} /></button>}
                      <button onClick={() => deleteLoan(loan.id)} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground"><Trash2 size={14} /></button>
                    </div>
                  </div>
                  <Progress value={percentage} className={`h-2.5 mb-2 ${isComplete ? "[&>div]:bg-income" : "[&>div]:bg-primary"}`} />
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground font-mono">৳{paid.toLocaleString("bn-BD")} / ৳{loan.totalAmount.toLocaleString("bn-BD")} পরিশোধ</span>
                    <span className={`font-semibold ${isComplete ? "text-income" : "text-foreground"}`}>{isComplete ? "✅ সম্পন্ন" : `৳${loan.remainingAmount.toLocaleString("bn-BD")} বাকি`}</span>
                  </div>
                  {nextEmi && !isComplete && loan.emiAmount && (
                    <div className="mt-2 p-2 rounded-lg bg-secondary text-xs">
                      <span className="text-muted-foreground">📅 পরবর্তী কিস্তি: ৳{loan.emiAmount.toLocaleString("bn-BD")} — {nextEmi.toLocaleDateString("bn-BD", { day: "numeric", month: "long" })}</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogContent className="sm:max-w-md mx-4 rounded-2xl border-border bg-card">
            <DialogHeader><DialogTitle className="text-foreground text-lg font-semibold">নতুন লোন</DialogTitle></DialogHeader>
            <div className="flex gap-2 p-1 bg-secondary rounded-xl">
              <button onClick={() => setLoanType("taken")} className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${loanType === "taken" ? "bg-expense text-expense-foreground shadow-sm" : "text-muted-foreground"}`}>ধার নিয়েছি</button>
              <button onClick={() => setLoanType("given")} className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${loanType === "given" ? "bg-income text-income-foreground shadow-sm" : "text-muted-foreground"}`}>ধার দিয়েছি</button>
            </div>
            <input type="text" value={loanName} onChange={(e) => setLoanName(e.target.value)} placeholder="লোনের নাম (যেমন: ফোনের লোন)" className="w-full px-4 py-3 bg-secondary rounded-xl text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-ring" />
            <input type="text" value={personName} onChange={(e) => setPersonName(e.target.value)} placeholder="ব্যক্তির নাম" className="w-full px-4 py-3 bg-secondary rounded-xl text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-ring" />
            <div className="text-center py-2">
              <p className="text-xs text-muted-foreground mb-2">মোট পরিমাণ</p>
              <div className="flex items-center justify-center gap-1">
                <span className="text-2xl font-bold text-foreground">৳</span>
                <input type="number" value={totalAmount} onChange={(e) => setTotalAmount(e.target.value)} placeholder="0" className="text-3xl font-bold text-center bg-transparent outline-none w-40 text-foreground placeholder:text-muted-foreground font-mono" />
              </div>
            </div>
            <div className="flex gap-3">
              <div className="flex-1">
                <p className="text-xs text-muted-foreground mb-1.5">কিস্তির পরিমাণ (ঐচ্ছিক)</p>
                <input type="number" value={emiAmount} onChange={(e) => setEmiAmount(e.target.value)} placeholder="৳ 0" className="w-full px-3 py-2.5 bg-secondary rounded-xl text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-ring font-mono" />
              </div>
              <div className="w-24">
                <p className="text-xs text-muted-foreground mb-1.5">তারিখ</p>
                <input type="number" value={emiDay} onChange={(e) => setEmiDay(e.target.value)} placeholder="১-৩১" min={1} max={31} className="w-full px-3 py-2.5 bg-secondary rounded-xl text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-ring font-mono" />
              </div>
            </div>
            <button onClick={handleAddLoan} className="w-full py-3.5 rounded-xl text-sm font-semibold bg-primary text-primary-foreground hover:opacity-90 transition-all">সেভ করুন</button>
          </DialogContent>
        </Dialog>

        <Dialog open={!!payLoanId} onOpenChange={() => setPayLoanId(null)}>
          <DialogContent className="sm:max-w-md mx-4 rounded-2xl border-border bg-card">
            <DialogHeader><DialogTitle className="text-foreground text-lg font-semibold">কিস্তি পরিশোধ</DialogTitle></DialogHeader>
            <div className="text-center py-4">
              <div className="flex items-center justify-center gap-1">
                <span className="text-2xl font-bold text-foreground">৳</span>
                <input type="number" value={payAmount} onChange={(e) => setPayAmount(e.target.value)} placeholder="0" autoFocus className="text-3xl font-bold text-center bg-transparent outline-none w-40 text-foreground placeholder:text-muted-foreground font-mono" />
              </div>
            </div>
            <button onClick={handlePayment} className="w-full py-3.5 rounded-xl text-sm font-semibold bg-expense text-expense-foreground hover:opacity-90 transition-all">পরিশোধ করুন</button>
          </DialogContent>
        </Dialog>
      </div>
      <BottomNav />
    </div>
  );
};

export default LoanPage;
