import { useState, useMemo } from "react";
import { TransactionCategory, CATEGORIES } from "@/lib/finance-types";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { useTransactions } from "@/hooks/useTransactions";
import { useBudgets } from "@/hooks/useBudgets";
import BottomNav from "@/components/BottomNav";
import ThemeToggle from "@/components/ThemeToggle";

const getCurrentMonth = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
};

const BudgetPage = () => {
  const { transactions } = useTransactions();
  const { budgets, addBudget, updateBudget, deleteBudget } = useBudgets();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingBudgetId, setEditingBudgetId] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<TransactionCategory>("food");
  const [limitAmount, setLimitAmount] = useState("");

  const currentMonth = getCurrentMonth();
  const monthlyBudgets = budgets.filter((b) => b.month === currentMonth);

  const monthlySpending = useMemo(() => {
    const now = new Date();
    return transactions
      .filter(
        (t) =>
          t.type === "expense" &&
          new Date(t.date).getMonth() === now.getMonth() &&
          new Date(t.date).getFullYear() === now.getFullYear()
      )
      .reduce((acc, t) => {
        acc[t.category] = (acc[t.category] || 0) + t.amount;
        return acc;
      }, {} as Record<string, number>);
  }, [transactions]);

  const handleSave = async () => {
    if (!limitAmount || parseFloat(limitAmount) <= 0) return;

    if (editingBudgetId) {
      await updateBudget(editingBudgetId, {
        category: selectedCategory,
        limit: parseFloat(limitAmount),
      });
    } else {
      const exists = monthlyBudgets.find((b) => b.category === selectedCategory);
      if (exists) return;
      await addBudget({
        category: selectedCategory,
        limit: parseFloat(limitAmount),
        month: currentMonth,
      });
    }
    setDialogOpen(false);
    setEditingBudgetId(null);
    setLimitAmount("");
  };

  const openEdit = (b: { id: string; category: TransactionCategory; limit: number }) => {
    setEditingBudgetId(b.id);
    setSelectedCategory(b.category);
    setLimitAmount(String(b.limit));
    setDialogOpen(true);
  };

  const openAdd = () => {
    setEditingBudgetId(null);
    setSelectedCategory("food");
    setLimitAmount("");
    setDialogOpen(true);
  };

  const usedCategories = monthlyBudgets.map((b) => b.category);

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="px-5 pt-6 pb-4 flex items-center justify-between">
        <h1 className="text-xl font-bold text-foreground">বাজেট প্ল্যানার</h1>
        <ThemeToggle />
      </div>
      <div className="px-5">
        <div className="flex items-center justify-end mb-4">
          <button
            onClick={openAdd}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium"
          >
            <Plus size={16} /> যুক্ত করুন
          </button>
        </div>

        {monthlyBudgets.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <span className="text-5xl block mb-3">📋</span>
            <p className="text-sm">এই মাসে কোনো বাজেট সেট করা হয়নি</p>
            <p className="text-xs mt-1">উপরের 'যুক্ত করুন' বাটন দিয়ে বাজেট সেট করুন</p>
          </div>
        ) : (
          <div className="space-y-3">
            {monthlyBudgets.map((b) => {
              const spent = monthlySpending[b.category] || 0;
              const percentage = Math.min((spent / b.limit) * 100, 100);
              const isWarning = percentage >= 80 && percentage < 100;
              const isOver = percentage >= 100;

              return (
                <div
                  key={b.id}
                  className={`p-4 rounded-2xl bg-card border transition-all ${
                    isOver ? "border-expense/50 bg-expense/5" : isWarning ? "border-chart-3/50 bg-chart-3/5" : "border-border"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{CATEGORIES[b.category].icon}</span>
                      <span className="text-sm font-semibold text-foreground">{CATEGORIES[b.category].label}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <button onClick={() => openEdit(b)} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground"><Pencil size={14} /></button>
                      <button onClick={() => deleteBudget(b.id)} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground"><Trash2 size={14} /></button>
                    </div>
                  </div>
                  <Progress value={percentage} className={`h-2.5 mb-2 ${isOver ? "[&>div]:bg-expense" : isWarning ? "[&>div]:bg-chart-3" : "[&>div]:bg-primary"}`} />
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">৳{spent.toLocaleString("bn-BD")} / ৳{b.limit.toLocaleString("bn-BD")}</span>
                    <span className={`font-semibold ${isOver ? "text-expense" : isWarning ? "text-chart-3" : "text-primary"}`}>
                      {isOver ? `৳${(spent - b.limit).toLocaleString("bn-BD")} অতিরিক্ত!` : `৳${(b.limit - spent).toLocaleString("bn-BD")} বাকি`}
                    </span>
                  </div>
                  {isWarning && !isOver && <p className="text-xs text-chart-3 mt-1.5 font-medium">⚠️ বাজেটের {Math.round(percentage)}% ব্যবহৃত হয়েছে</p>}
                  {isOver && <p className="text-xs text-expense mt-1.5 font-medium">🚨 বাজেট অতিক্রম করেছে!</p>}
                </div>
              );
            })}
          </div>
        )}

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="sm:max-w-md mx-4 rounded-2xl border-border bg-card">
            <DialogHeader>
              <DialogTitle className="text-foreground text-lg font-semibold">
                {editingBudgetId ? "বাজেট সম্পাদনা" : "নতুন বাজেট"}
              </DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-4 gap-2">
              {(Object.keys(CATEGORIES) as TransactionCategory[]).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  disabled={!editingBudgetId && usedCategories.includes(cat)}
                  className={`flex flex-col items-center gap-1 p-2.5 rounded-xl text-xs transition-all ${
                    selectedCategory === cat
                      ? "bg-accent text-accent-foreground ring-1 ring-primary/30"
                      : !editingBudgetId && usedCategories.includes(cat)
                      ? "bg-secondary/50 text-muted-foreground/40 cursor-not-allowed"
                      : "bg-secondary text-muted-foreground hover:bg-accent/50"
                  }`}
                >
                  <span className="text-lg">{CATEGORIES[cat].icon}</span>
                  <span className="font-medium">{CATEGORIES[cat].label}</span>
                </button>
              ))}
            </div>
            <div className="text-center py-3">
              <p className="text-xs text-muted-foreground mb-2">মাসিক সীমা</p>
              <div className="flex items-center justify-center gap-1">
                <span className="text-2xl font-bold text-foreground">৳</span>
                <input type="number" value={limitAmount} onChange={(e) => setLimitAmount(e.target.value)} placeholder="0" className="text-3xl font-bold text-center bg-transparent outline-none w-40 text-foreground placeholder:text-muted-foreground font-mono" />
              </div>
            </div>
            <button onClick={handleSave} className="w-full py-3.5 rounded-xl text-sm font-semibold bg-primary text-primary-foreground hover:opacity-90 transition-all">সেভ করুন</button>
          </DialogContent>
        </Dialog>
      </div>
      <BottomNav />
    </div>
  );
};

export default BudgetPage;
