import { useState } from "react";
import { Plus, LogOut } from "lucide-react";
import { Transaction } from "@/lib/finance-types";
import { useAuth } from "@/contexts/AuthContext";
import { useTransactions } from "@/hooks/useTransactions";
import ThemeToggle from "@/components/ThemeToggle";
import SpendingChart from "@/components/SpendingChart";
import TransactionList from "@/components/TransactionList";
import AddTransactionDialog from "@/components/AddTransactionDialog";
import BottomNav from "@/components/BottomNav";

const Index = () => {
  const { signOut } = useAuth();
  const { transactions, addTransaction, updateTransaction, deleteTransaction } = useTransactions();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  const handleEdit = (txn: Transaction) => {
    setEditingTransaction(txn);
    setDialogOpen(true);
  };

  const cashBalance = transactions.reduce((sum, t) => {
    if (t.source !== "cash") return sum;
    return t.type === "income" ? sum + t.amount : sum - t.amount;
  }, 0);

  const bankBalance = transactions.reduce((sum, t) => {
    if (t.source !== "bank") return sum;
    return t.type === "income" ? sum + t.amount : sum - t.amount;
  }, 0);

  const totalBalance = cashBalance + bankBalance;

  const thisMonthExpenses = transactions
    .filter((t) => {
      const now = new Date();
      const d = new Date(t.date);
      return t.type === "expense" && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    })
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="px-5 pt-6 pb-4 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">টাকা ট্র্যাকার</h1>
          <p className="text-xs text-muted-foreground">আপনার ডিজিটাল ফিন্যান্সিয়াল অ্যাসিস্ট্যান্ট</p>
        </div>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <button
            onClick={signOut}
            className="p-2 rounded-xl hover:bg-secondary text-muted-foreground"
            title="লগআউট"
          >
            <LogOut size={18} />
          </button>
        </div>
      </div>

      <div className="px-5 mb-5">
        <div className="balance-gradient rounded-2xl p-5 text-primary-foreground">
          <p className="text-sm opacity-80 mb-1">মোট ব্যালেন্স</p>
          <p className="text-3xl font-bold font-mono tracking-tight">
            ৳{totalBalance.toLocaleString("bn-BD")}
          </p>
          <div className="flex gap-6 mt-4">
            <div>
              <p className="text-xs opacity-70">💵 নগদ</p>
              <p className="text-sm font-semibold font-mono">৳{cashBalance.toLocaleString("bn-BD")}</p>
            </div>
            <div>
              <p className="text-xs opacity-70">🏦 ব্যাংক</p>
              <p className="text-sm font-semibold font-mono">৳{bankBalance.toLocaleString("bn-BD")}</p>
            </div>
            <div className="ml-auto">
              <p className="text-xs opacity-70">এই মাসের খরচ</p>
              <p className="text-sm font-semibold font-mono">৳{thisMonthExpenses.toLocaleString("bn-BD")}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="px-5 mb-5">
        <div className="bg-card rounded-2xl p-4 border border-border">
          <h2 className="text-sm font-semibold text-foreground mb-3">খরচের বিশ্লেষণ</h2>
          <SpendingChart transactions={transactions} />
        </div>
      </div>

      <div className="px-5">
        <h2 className="text-sm font-semibold text-foreground mb-3">সাম্প্রতিক লেনদেন</h2>
        <TransactionList transactions={transactions} onDelete={deleteTransaction} onEdit={handleEdit} />
      </div>

      <div className="fixed bottom-20 right-5 z-50">
        <button
          onClick={() => { setEditingTransaction(null); setDialogOpen(true); }}
          className="w-14 h-14 rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/30 flex items-center justify-center hover:scale-105 active:scale-95 transition-transform"
        >
          <Plus size={28} strokeWidth={2.5} />
        </button>
      </div>

      <AddTransactionDialog
        open={dialogOpen}
        onOpenChange={(open) => { setDialogOpen(open); if (!open) setEditingTransaction(null); }}
        onAdd={addTransaction}
        editTransaction={editingTransaction}
        onUpdate={updateTransaction}
      />
      <BottomNav />
    </div>
  );
};

export default Index;
