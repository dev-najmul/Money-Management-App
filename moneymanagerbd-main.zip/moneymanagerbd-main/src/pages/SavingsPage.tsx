import { useState } from "react";
import { Plus, Trash2, PiggyBank } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { useSavings } from "@/hooks/useSavings";
import BottomNav from "@/components/BottomNav";
import ThemeToggle from "@/components/ThemeToggle";

const GOAL_ICONS = ["🎯", "📱", "🏠", "🚗", "✈️", "💍", "🎓", "💻"];

const SavingsPage = () => {
  const { goals, addGoal, addDeposit, deleteGoal } = useSavings();
  const [addGoalOpen, setAddGoalOpen] = useState(false);
  const [depositGoalId, setDepositGoalId] = useState<string | null>(null);
  const [goalName, setGoalName] = useState("");
  const [goalTarget, setGoalTarget] = useState("");
  const [goalIcon, setGoalIcon] = useState("🎯");
  const [depositAmount, setDepositAmount] = useState("");

  const handleAddGoal = async () => {
    if (!goalName || !goalTarget || parseFloat(goalTarget) <= 0) return;
    await addGoal({ name: goalName, targetAmount: parseFloat(goalTarget), icon: goalIcon });
    setAddGoalOpen(false);
    setGoalName("");
    setGoalTarget("");
    setGoalIcon("🎯");
  };

  const handleDeposit = async () => {
    if (!depositGoalId || !depositAmount || parseFloat(depositAmount) <= 0) return;
    await addDeposit(depositGoalId, parseFloat(depositAmount));
    setDepositGoalId(null);
    setDepositAmount("");
  };

  const getEstimatedDate = (goal: { savedAmount: number; targetAmount: number; deposits: { date: string }[] }) => {
    if (goal.deposits.length < 2 || goal.savedAmount >= goal.targetAmount) return null;
    const sorted = [...goal.deposits].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    const firstDate = new Date(sorted[0].date).getTime();
    const lastDate = new Date(sorted[sorted.length - 1].date).getTime();
    const daysDiff = (lastDate - firstDate) / (1000 * 60 * 60 * 24);
    if (daysDiff <= 0) return null;
    const dailyRate = goal.savedAmount / daysDiff;
    const remaining = goal.targetAmount - goal.savedAmount;
    const daysNeeded = remaining / dailyRate;
    const est = new Date(Date.now() + daysNeeded * 24 * 60 * 60 * 1000);
    return est.toLocaleDateString("bn-BD", { year: "numeric", month: "long", day: "numeric" });
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="px-5 pt-6 pb-4 flex items-center justify-between">
        <h1 className="text-xl font-bold text-foreground">সেভিংস ট্র্যাকার</h1>
        <ThemeToggle />
      </div>
      <div className="px-5">
        <div className="flex items-center justify-end mb-4">
          <button onClick={() => setAddGoalOpen(true)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium">
            <Plus size={16} /> নতুন লক্ষ্য
          </button>
        </div>

        {goals.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <span className="text-5xl block mb-3">🎯</span>
            <p className="text-sm">এখনো কোনো সঞ্চয় লক্ষ্য নেই</p>
            <p className="text-xs mt-1">উপরের বাটন দিয়ে আপনার লক্ষ্য সেট করুন</p>
          </div>
        ) : (
          <div className="space-y-3">
            {goals.map((goal) => {
              const percentage = Math.min((goal.savedAmount / goal.targetAmount) * 100, 100);
              const isComplete = goal.savedAmount >= goal.targetAmount;
              const estimated = getEstimatedDate(goal);
              return (
                <div key={goal.id} className={`p-4 rounded-2xl bg-card border transition-all ${isComplete ? "border-income/50 bg-income/5" : "border-border"}`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2.5">
                      <span className="text-2xl">{goal.icon}</span>
                      <div>
                        <p className="text-sm font-semibold text-foreground">{goal.name}</p>
                        <p className="text-xs text-muted-foreground">{isComplete ? "✅ লক্ষ্য পূরণ!" : `৳${goal.targetAmount.toLocaleString("bn-BD")} লক্ষ্য`}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      {!isComplete && <button onClick={() => setDepositGoalId(goal.id)} className="p-1.5 rounded-lg hover:bg-secondary text-primary"><PiggyBank size={16} /></button>}
                      <button onClick={() => deleteGoal(goal.id)} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground"><Trash2 size={14} /></button>
                    </div>
                  </div>
                  <Progress value={percentage} className={`h-2.5 mb-2 ${isComplete ? "[&>div]:bg-income" : "[&>div]:bg-primary"}`} />
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground font-mono">৳{goal.savedAmount.toLocaleString("bn-BD")} / ৳{goal.targetAmount.toLocaleString("bn-BD")}</span>
                    <span className={`font-semibold ${isComplete ? "text-income" : "text-primary"}`}>{Math.round(percentage)}%</span>
                  </div>
                  {estimated && !isComplete && <p className="text-xs text-muted-foreground mt-2">📅 আনুমানিক সম্পন্ন: {estimated}</p>}
                </div>
              );
            })}
          </div>
        )}

        <Dialog open={addGoalOpen} onOpenChange={setAddGoalOpen}>
          <DialogContent className="sm:max-w-md mx-4 rounded-2xl border-border bg-card">
            <DialogHeader><DialogTitle className="text-foreground text-lg font-semibold">নতুন সঞ্চয় লক্ষ্য</DialogTitle></DialogHeader>
            <div className="flex gap-2 flex-wrap justify-center">
              {GOAL_ICONS.map((icon) => (
                <button key={icon} onClick={() => setGoalIcon(icon)} className={`w-11 h-11 rounded-xl text-xl flex items-center justify-center transition-all ${goalIcon === icon ? "bg-accent ring-1 ring-primary/30" : "bg-secondary"}`}>{icon}</button>
              ))}
            </div>
            <input type="text" value={goalName} onChange={(e) => setGoalName(e.target.value)} placeholder="লক্ষ্যের নাম (যেমন: নতুন ফোন)" className="w-full px-4 py-3 bg-secondary rounded-xl text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-ring" />
            <div className="text-center py-2">
              <p className="text-xs text-muted-foreground mb-2">লক্ষ্যমাত্রা</p>
              <div className="flex items-center justify-center gap-1">
                <span className="text-2xl font-bold text-foreground">৳</span>
                <input type="number" value={goalTarget} onChange={(e) => setGoalTarget(e.target.value)} placeholder="0" className="text-3xl font-bold text-center bg-transparent outline-none w-40 text-foreground placeholder:text-muted-foreground font-mono" />
              </div>
            </div>
            <button onClick={handleAddGoal} className="w-full py-3.5 rounded-xl text-sm font-semibold bg-primary text-primary-foreground hover:opacity-90 transition-all">সেভ করুন</button>
          </DialogContent>
        </Dialog>

        <Dialog open={!!depositGoalId} onOpenChange={() => setDepositGoalId(null)}>
          <DialogContent className="sm:max-w-md mx-4 rounded-2xl border-border bg-card">
            <DialogHeader><DialogTitle className="text-foreground text-lg font-semibold">টাকা জমা করুন</DialogTitle></DialogHeader>
            <div className="text-center py-4">
              <div className="flex items-center justify-center gap-1">
                <span className="text-2xl font-bold text-foreground">৳</span>
                <input type="number" value={depositAmount} onChange={(e) => setDepositAmount(e.target.value)} placeholder="0" autoFocus className="text-3xl font-bold text-center bg-transparent outline-none w-40 text-foreground placeholder:text-muted-foreground font-mono" />
              </div>
            </div>
            <button onClick={handleDeposit} className="w-full py-3.5 rounded-xl text-sm font-semibold bg-income text-income-foreground hover:opacity-90 transition-all">জমা করুন</button>
          </DialogContent>
        </Dialog>
      </div>
      <BottomNav />
    </div>
  );
};

export default SavingsPage;
