export type TransactionCategory =
  | "food"
  | "transport"
  | "shopping"
  | "bills"
  | "health"
  | "education"
  | "entertainment"
  | "other";

export interface Transaction {
  id: string;
  amount: number;
  type: "income" | "expense";
  category: TransactionCategory;
  note: string;
  source: "cash" | "bank";
  date: string;
}

export const CATEGORIES: Record<TransactionCategory, { label: string; icon: string; color: string }> = {
  food: { label: "খাবার", icon: "🍔", color: "hsl(var(--chart-3))" },
  transport: { label: "যাতায়াত", icon: "🚌", color: "hsl(var(--chart-2))" },
  shopping: { label: "কেনাকাটা", icon: "🛍️", color: "hsl(var(--chart-4))" },
  bills: { label: "বিল", icon: "📄", color: "hsl(var(--chart-5))" },
  health: { label: "স্বাস্থ্য", icon: "💊", color: "hsl(var(--chart-1))" },
  education: { label: "শিক্ষা", icon: "📚", color: "hsl(var(--chart-2))" },
  entertainment: { label: "বিনোদন", icon: "🎮", color: "hsl(var(--chart-3))" },
  other: { label: "অন্যান্য", icon: "📌", color: "hsl(var(--chart-4))" },
};

// Budget types
export interface Budget {
  id: string;
  category: TransactionCategory;
  limit: number;
  month: string; // "YYYY-MM"
}

// Savings Goal types
export interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  savedAmount: number;
  icon: string;
  createdAt: string;
  deposits: SavingsDeposit[];
}

export interface SavingsDeposit {
  id: string;
  amount: number;
  date: string;
}

// Loan types
export interface Loan {
  id: string;
  name: string;
  type: "given" | "taken"; // given = I gave money, taken = I borrowed
  personName: string;
  totalAmount: number;
  remainingAmount: number;
  emiAmount?: number;
  emiDay?: number; // day of month for EMI
  createdAt: string;
  payments: LoanPayment[];
}

export interface LoanPayment {
  id: string;
  amount: number;
  date: string;
}
